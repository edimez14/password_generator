# Password Generator

Random password generator using the random package.

Generates secure and reliable passwords

version 0.4